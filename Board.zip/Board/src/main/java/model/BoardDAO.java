package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class BoardDAO {
	
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
	
	// DB의 커넥션 풀을 이용
	public void getCon() {
		
		try {
			Context initctx = new InitialContext();
			Context envctx = (Context) initctx.lookup("java:com/env");
			DataSource ds = (DataSource) envctx.lookup("jdbc/pool");
			//
			con = ds.getConnection();
			
		} catch (Exception e) {
		 e.printStackTrace();
	}

	}
	//
	public void insertBoard(BoardBean bean) {
		
		getCon();
		// 넘어오지 않은 데이터는 초기화 해준다.
		int ref=0; // 글 그룹을 의미 = 쿼리를 실행시켜서 가장 큰 ref를 가져온 후 +1
		int re_step=1;
		int re_level=1;
		
		try {
			// 가장 큰 ref값을 읽어오는 쿼리 준비
			String refsql = "select max(ref) from board";
			// 쿼리 실행 후 결과물 처리
			pstmt= con.prepareStatement(refsql);
			if(rs.next()) {
				ref = rs.getInt(1)+1; //Max값에 1을 추가하여 글 그룹을 생성함
			}
			//게시글 전체값을 테이블에 저장함                                                                                                                                                                                                                                                                 
			
			String sql = "insert into board(board_seq.NEXTVAL, ?, ?, ?, ?, sysdate, ?, ?, ? 0, ?)";
			pstmt = con.prepareStatement(sql);
			//?에 값을 mapping;
			pstmt.setString(1,  bean.getWriter());
			pstmt.setString(2,  bean.getEmail());
			pstmt.setString(3,  bean.getSubject());
			pstmt.setString(4,  bean.getPassword());
			pstmt.setInt(5,  ref);
			pstmt.setInt(6,  re_step);
			pstmt.setInt(7,  re_level);
			pstmt.setString(8,  bean.getContent());
			// 쿼리를 실행할 것
			pstmt.executeUpdate();
			//자원 반납
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	
	}
	
}
